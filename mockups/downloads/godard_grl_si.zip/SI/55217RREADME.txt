MS#2013gl055217
Frequency-dependent Landscape Response to
Climatic Forcing
Vincent Godard1,  Gregory E. Tucker2,  G. Burch Fisher,3, Douglas W. Burbank3,  and Bodo Bookhagen3


  Corresponding  author:  V. Godard,  CEREGE,  Aix-Marseille University  Europole de l�Arbois, Aix-en-Provence, France  (godard@cerege.fr)

   1Aix-Marseille Universit�e, CNRS, IRD, CEREGE  UM34, 13545 Aix-en-Provence, France
   2Cooperative  Institute for Research in Environmental Sciences (CIRES)  and Department of Geological Sciences, University of Colorado, Boulder, USA
3Earth  Research Institute, UC Santa

Barbara,  Santa  Barbara,  USA


Methods
Model runs start from a near zero elevation topography affected by a random perturbation.
Base level is fixed to zero along the two opposite longest boundaries of the model and defined as a symmetrical boundary condition along the two other sides.
Sediment flux is calculated at each time step based on the incremental differences in landscape volume corrected for the amount of uplift. Our formulation is strictly detachment-limited, all sediment produced by erosion is evacuated instantaneously and no sediment storage is considered.
We consider that steady state is reached when sediment flux is constant with time.

Supplementary figure 1

Short description�: Stream Power evolution along-stream

Caption�: Steam power evolution along a single channel. The different curves represent different time steps over a complete oscillation cycle in precipitation (1 m/yr +/- 10�%). Three different periods of oscillations are tested�: 50 ky (2.5 ky  time-steps between curves), 130 ky (10 ky time-steps) and 600 ky (20 ky time-steps).
Short periods (50 ky) do not allow for a full propagation of the oscillations to the channel heads. Long periods (600 ky) are slow enough so that the channel has enough time to adjust to new conditions without developing major knickpoints. Only intermediate periods (130 ky) allow the development of a significant perturbation that propagates all the way to the channel heads.
Note that when interpreting the stream power oscillations (observed here along a single channel) at the scale of the whole landscape, one must take into account the existence of tributaries to this main channel. Small tributaries in the headwaters (~0-100 m on the figure) will be activated by the intermediate oscillation period (130 ky) and contribute to amplifying this response at the scale of the landscape. In contrast, shorter oscillations, e.g., 50 kyr, do not activate these headwater regions.

Supplementary figure 2

Short description�: Influence of basin length on maximum response period

Caption�: We vary the width of the model (dimension perpendicular to the main divide) from 500 to 8000 m. A model width of 1000 m, as in the reference case, corresponds to a basin length of 500 m (see Fig. 2a). We vary the model length accordingly to preserve the aspect ratio. Cell size is also modified in proportion. Stream power theory predicts that the system response time should be independent of the spatial dimension, which is what we observe  with no hillslope diffusion. Introducing hillslope diffusion implies that small basins present a significant damping of the response over the hillslope domain where the propagation of erosion is progressively slowed down, and the overall response of the landscape is decreased accordingly. Increasing the basin size results in a progressive decrease in the global influence of hillslope diffusion, such that larger basins have a behavior which converges toward the no diffusion case.

Supplementary figure 3

Short description�: Influence of the average precipitation on maximum response period

Caption�: We explore a range of average precipitation values and report the maximum response period for each of them. Stream power theory predicts that the fluvial response time should scale to the inverse square root of precipitation. Models where significant hillslope diffusion is considered depart slightly from this relation. Turning off hillslope diffusion yields results that are consistent with the predicted scaling.

Supplementary figure 4

Short description�: Influence of the amplitude of oscillations around the mean on response period

Caption�: We vary the amplitude of precipitation oscillations around the mean (1 m/yr) and report the amplitude response for forcing periods in the 100-800 kyr range. We observe no significant influence of the amplitude of the forcing on the maximum response period, which appears to be mostly controlled by the average value of precipitation.


Supplementary figure 5

Short description�: Comparison between maximum response periods and erosion wave propagation times across the model

Caption�: Comparison of the propagation time of knickpoints across the model space with the resonance period. Under the assumption that fluvial incision is proportional to specific stream power, we can use knickpoint celerity (which is function of erodibility, precipitation and area) and Hack's law  and integrate over a stream of length L (500 m in our reference model), to derive the propagation time for a knickpoint across the catchment (Tk), which is only weakly dependent on basin length L (power 0.2 in our case). 
We compare this calculated value for a 1D linear stream with the observed resonance period in our 2D modeled landscape for different K values (as in Fig. 3 of the main text). Without diffusion the two times are similar, suggesting that the key control on the landscape response to oscillating forcings is the ability to transmit information over the full extent of the river network, as suggested by supplementary figure S1. Diffusion processes slow down the response due to the damping of the erosion signal over the hillslope domain. This why when diffusion is considered (red curve), and for high value of erodibility (i.e. long periods and low P�clet numbers), there is an increasing difference  between the analytical propagation time and modeled resonance period.



Supplementary figure 6

Short description�: Example of responses to the change in the spectral content of the climatic forcing, from 40 to 100 kyr dominant periods

Caption�: We compare the time evolution of the sediment flux in response to a shift from 40 to 100 kyr periods in the input precipitation signal. We test two situations: the first one (blue curve) correspond to an erodibility that maximizes the response amplitude for 40-kyr oscillations (Fig. 3), while the second (red curve) maximizes the response amplitude for 100-kyr oscillations. The first response, which starts from resonance conditions (40 kyr) and shifts toward longer periods, displays the maximum differential in response amplitude between the two parts of the signal.  









